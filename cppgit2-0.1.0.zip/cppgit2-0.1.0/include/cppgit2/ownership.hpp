#pragma once

namespace cppgit2 {

enum class ownership { user, libgit2 };
}
